#' Pipe operator
#'
#' @name %>%
#' @rdname pipe
#' @keywords internal
#'
#' @importFrom magrittr %>%
NULL
